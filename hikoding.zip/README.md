Cara instal
- Jalankan terlebih dahulu perintah `composer install`
- Setelah itu, salin file `.env.example` ke `.env` dan sesuaikan konfigurasi di dalamnya
